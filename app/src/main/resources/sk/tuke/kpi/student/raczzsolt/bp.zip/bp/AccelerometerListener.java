/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.tuke.kpi.student.raczzsolt.bp;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.widget.TextView;
import java.io.PrintWriter;

/**
 *
 * @author zsolt
 */
public class AccelerometerListener implements SensorEventListener {

    private final TextView sensordata;
    private PrintWriter accelWriter;

    public AccelerometerListener(TextView sensordata, PrintWriter accelWriter) {
        this.sensordata = sensordata;
        this.accelWriter = accelWriter;
    }

    public void onSensorChanged(SensorEvent event) {
        sensordata.setText("[" + event.values[0] + ", " + event.values[1] + ", " + event.values[2] + "]");
        accelWriter.println(event.values[0] + ", " + event.values[1] + ", " + event.values[2]);
    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
