/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.tuke.kpi.student.raczzsolt.bp;

import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.widget.TextView;
import java.io.PrintWriter;

/**
 *
 * @author zsolt
 */
public class LocationSensorListener implements LocationListener {

    private final TextView locationdata;
    private final PrintWriter positionWriter;

    public LocationSensorListener(TextView locationdata, PrintWriter positionWriter) {
        this.locationdata = locationdata;
        this.positionWriter = positionWriter;
    }

    public void onLocationChanged(Location location) {
        locationdata.setText("[" + location.getLatitude() + ", " + location.getLongitude() + "], rýchlosť: " + location.getSpeed() + " m/s");
        this.positionWriter.println(System.currentTimeMillis() + ", " + location.getLatitude() + ", " + location.getLongitude() + ", " + location.getSpeed());
    }

    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    public void onProviderEnabled(String provider) {

    }

    public void onProviderDisabled(String provider) {

    }

}
