package sk.tuke.kpi.student.raczzsolt.bp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class MainActivity extends Activity {
    
    private PrintWriter accelWriter;
    private PrintWriter positionWriter;
    private SensorManager mSensorManager;
    private LocationManager mLocationManager;
    private Sensor mAcceleroMeter;
    private AccelerometerListener aListener;
    private LocationSensorListener lListener;
    private Handler mHandler;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        if (!this.isExternalStorageWritable()) {
            this.exitError("Nie je možné zapisovať na externé úložisko.");
        } else {
            File file1 = new File(this.getExternalFilesDir(null), "data_accel_" + System.currentTimeMillis() / 1000 + ".csv");
            File file2 = new File(this.getExternalFilesDir(null), "data_position_" + System.currentTimeMillis() / 1000 + ".csv");
            
            try {
                this.accelWriter = new PrintWriter(new FileWriter(file1));
            } catch (IOException ex) {
                this.exitError("Nepodarilo sa otvoriť súbor " + file1.getAbsolutePath() + " .");
            }
            
            try {
                this.positionWriter = new PrintWriter(new FileWriter(file2));
            } catch (IOException ex) {
                this.exitError("Nepodarilo sa otvoriť súbor " + file2.getAbsolutePath() + " .");
            }
            
        }
        
        TextView acceldata = (TextView) this.findViewById(R.id.acceldata);
        TextView locationinfo = (TextView) this.findViewById(R.id.location_info);
        Button exitButton = (Button) this.findViewById(R.id.exit);
        
        exitButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        
        this.aListener = new AccelerometerListener(acceldata, accelWriter);
        this.lListener = new LocationSensorListener(locationinfo, positionWriter);
        
        this.mSensorManager = (SensorManager) this.getSystemService(Context.SENSOR_SERVICE);
        this.mLocationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        this.mAcceleroMeter = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        
    }
    
    private boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return true;
        }
        return false;
    }
    
    private void exitError(String message) {
        new AlertDialog.Builder(this)
                .setMessage(message).setCancelable(true)
                .setNeutralButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .create()
                .show();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        this.mSensorManager.registerListener(this.aListener, mAcceleroMeter, SensorManager.SENSOR_DELAY_NORMAL);
        this.mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this.lListener);
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this.aListener);
        mLocationManager.removeUpdates(this.lListener);
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        accelWriter.close();
        positionWriter.close();
    }
    
}
